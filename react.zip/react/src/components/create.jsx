import React, { useState } from 'react'
import { Button, Checkbox, Form } from 'semantic-ui-react/'
import axios from 'axios'

export default function Create() {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [checkbox, setCheckbox] = useState(false)
  const postData = () => {
    axios.post('https://63780b135c477765122b6f91.mockapi.io/usuario',{firstName,lastName,checkbox}
    )}


return (
  <div>
    <Form className="create-form">
      <Form.Field>
        <label>Informe o nome:</label>
        <input placeholder='Primeiro Nome' onChange={(e) => setFirstName (e.target.value)} />
      </Form.Field>
      <Form.Field>
        <label>Informe o Sobrenome</label>
        <input placeholder='Ultimo Nome' onChange={(e) => setLastName (e.target.value)} />
      </Form.Field>
      <Form.Field>
        <Checkbox label='Eu aceito os termos e condições ' onChange={(e) => setCheckbox(!checkbox)} />
      </Form.Field>
        <Button type='submit' onClick={postData}>Enviar</Button>
    </Form>
</div>
)
}
