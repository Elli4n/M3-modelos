import React, { useState } from 'react'
import { Button, Form, FormField } from 'semantic-ui-react/'
import axios from 'axios'

export default function Create() {
    const [Name, setName] = useState('')
    const [Description, setDescription] = useState('')
    const [Quantidade, setQuantidade] = useState('')
    const [Preco, setPreco] = useState('')
    const Subtotal = (Quantidade*Preco);
    const postData = () => {
      axios.post('https://63780b135c477765122b6f91.mockapi.io/carrinho',{Name,Description,Quantidade,Preco,Subtotal}
      )
      alert('Objeto Adicionado com Sucesso!')
      window.location.reload()
    
    }
      
    
  return (
    <div>
      <Form className="create-form">
        <Form.Field>
          <label>Produto</label>
          <input placeholder='Nome do Produto' onChange={(e) => setName (e.target.value)} />
        </Form.Field>
        <Form.Field>
          <label>Descrição</label>
          <input placeholder='Descrição do Produto' onChange={(e) => setDescription (e.target.value)} />
        </Form.Field>
        <FormField>
          <label>Quantidade</label>
          <input placeholder='Quantidade' on onChange={(e) => setQuantidade (e.target.value)} />
        </FormField>
        <Form.Field>
          <label>Preço</label>
          <input placeholder='0.00' onChange={(e) => setPreco (e.target.value)} />
        </Form.Field>
          <Button type='submit' onClick={postData}>Enviar</Button>
      </Form>
  </div>
  )
  }
  