import React, { useEffect, useState } from 'react'
import { Button, Checkbox, Icon, Table } from 'semantic-ui-react'
import axios from 'axios'


export default function Read() {
    const [APIData, setAPIData] = useState([]);
    useEffect(() => {
      axios.get
      ('https://63780b135c477765122b6f91.mockapi.io/carrinho')
      .then((response) => {
        console.log(response.data)
        setAPIData(response.data);
      })
    }, []);

    const setData = (data) =>{
      let { id, Name, Description, Preco} = 
      data;
      localStorage.setItem('ID', id);
      localStorage.setItem('Produto', Name);
      localStorage.setItem('Descrição', Description);
      localStorage.setItem('Preço', Preco);
    }
    
    const onDelete = (id) => {
      if (window.confirm("Confirma Exclusão?")) {
        axios.delete
        (`https://63780b135c477765122b6f91.mockapi.io/carrinho/${id}`)
        .then(() => {
          getData()
        })
      }
    }
    const getData = () => {
        axios.get
        (`https://63780b135c477765122b6f91.mockapi.io/carrinho`)
        .then((getData) => {
        setAPIData(getData.data);
        })
    }
    
    return (
    <div>
        <Table singleLine>
    <Table.Header>
      <Table.Row>
        <Table.HeaderCell>Produto</Table.HeaderCell>
        <Table.HeaderCell>Descrição</Table.HeaderCell>
        <Table.HeaderCell>Preço</Table.HeaderCell>
      </Table.Row>
    </Table.Header>

    <Table.Body>
    {APIData.map((data) => {
     return (
       <Table.Row>
          <Table.Cell>{data.Name}</Table.Cell>
           <Table.Cell>{data.Description}</Table.Cell>
           <Table.Cell>{data.Preco}</Table.Cell>
           <Table.Cell><Button onClick={() => onDelete(data.id)}>Remover</Button></Table.Cell>
        </Table.Row>
   )})}
    </Table.Body>
    </Table>

    </div>
    )
}