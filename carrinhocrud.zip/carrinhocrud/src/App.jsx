import './App.css'
import Create from './components/create'
import Read from './components/read'


function App() {

  return (
    <div className="main">

        <h2 className="main-header">Carrinho de Compras</h2><br/>

      <div>
        <Create/>  <br /><br />
      </div>
      <div>
        <Read/> 
      </div>

    </div>
  )
}

export default App
